#include "CelestialBody.h"

CelestialBody::CelestialBody(std::string bodyName, double initialX, double initialY, double initialSpeedX, double initialSpeedY, double bodyMass)
    : name(std::move(bodyName)), x(initialX), y(initialY), speedX(initialSpeedX), speedY(initialSpeedY), mass(bodyMass) {}

double CelestialBody::getX() const { return x; }
double CelestialBody::getY() const { return y; }
double CelestialBody::getSpeedX() const { return speedX; }
double CelestialBody::getSpeedY() const { return speedY; }
double CelestialBody::getMass() const { return mass; }

void CelestialBody::setPhysicsState(double newX, double newY, double newSpeedX, double newSpeedY) {
    x = newX; y = newY; speedX = newSpeedX; speedY = newSpeedY;
}

std::string CelestialBody::getDetails() const {
    return name + " | Mass: " + std::to_string(mass) + 
           " | Pos: (" + std::to_string(x) + ", " + std::to_string(y) + ")" +
           " | Speed: (" + std::to_string(speedX) + ", " + std::to_string(speedY) + ")";
}

void CelestialBody::display() const {
    std::cout << getDetails() << '\n';
}

Planet::Planet(std::string bodyName, double x, double y, double speedX, double speedY, double mass, std::string a)
    : CelestialBody(std::move(bodyName), x, y, speedX, speedY, mass), atmosphere(std::move(a)) {}

std::string Planet::getDetails() const {
    return "[Planet] " + CelestialBody::getDetails() + " | Atmos: " + atmosphere;
}

Star::Star(std::string bodyName, double x, double y, double speedX, double speedY, double mass, int b)
    : CelestialBody(std::move(bodyName), x, y, speedX, speedY, mass), brightness(b) {}

std::string Star::getDetails() const {
    return "[Star] " + CelestialBody::getDetails() + " | Brightness: " + std::to_string(brightness);
}

BlackHole::BlackHole(std::string bodyName, double x, double y, double speedX, double speedY, double mass, int pull)
    : CelestialBody(std::move(bodyName), x, y, speedX, speedY, mass), pullPower(pull) {}

std::string BlackHole::getDetails() const {
    return "[Black Hole] " + CelestialBody::getDetails() + " | Pull Power: " + std::to_string(pullPower);
}
