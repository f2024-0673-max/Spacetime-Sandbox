#ifndef PHYSICSENGINE_H
#define PHYSICSENGINE_H

#include <vector>
#include <memory>
#include <string>
#include "CelestialBody.h"

class IPhysicsEngine {
public:
    virtual ~IPhysicsEngine() = default;
    virtual void applyPhysics(std::vector<std::unique_ptr<CelestialBody>>& bodies) const = 0;
    virtual std::string getEngineName() const = 0;
};

class StablePhysics : public IPhysicsEngine {
public:
    void applyPhysics(std::vector<std::unique_ptr<CelestialBody>>& bodies) const override;
    std::string getEngineName() const override;
};

class GravityPhysics : public IPhysicsEngine {
private:
    const double gravityStrength = 0.5;
public:
    void applyPhysics(std::vector<std::unique_ptr<CelestialBody>>& bodies) const override;
    std::string getEngineName() const override;
};

#endif
