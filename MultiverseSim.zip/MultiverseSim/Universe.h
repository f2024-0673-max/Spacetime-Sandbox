#ifndef UNIVERSE_H
#define UNIVERSE_H

#include <vector>
#include <memory>
#include <string>
#include "PhysicsEngine.h"
#include "CelestialBody.h"

class Universe {
private:
    std::unique_ptr<IPhysicsEngine> physicsEngine;
    std::vector<std::unique_ptr<CelestialBody>> bodies;

public:
    explicit Universe(std::unique_ptr<IPhysicsEngine> engine);

    void addBody(std::unique_ptr<CelestialBody> body);
    void simulate();
    void display() const;
    void triggerSupernova();

    const std::vector<std::unique_ptr<CelestialBody>>& getBodies() const;
    std::string getEngineName() const;
};

#endif
