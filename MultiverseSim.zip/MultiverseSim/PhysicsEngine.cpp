#include "PhysicsEngine.h"
#include <cmath>

void StablePhysics::applyPhysics(std::vector<std::unique_ptr<CelestialBody>>& bodies) const {
    for (auto& body : bodies) {
        body->setPhysicsState(
            body->getX() + body->getSpeedX(),
            body->getY() + body->getSpeedY(),
            body->getSpeedX(),
            body->getSpeedY()
        );
    }
}

std::string StablePhysics::getEngineName() const { 
    return "Stable (Linear)"; 
}

void GravityPhysics::applyPhysics(std::vector<std::unique_ptr<CelestialBody>>& bodies) const {
    for (size_t i = 0; i < bodies.size(); ++i) {
        double totalPullX = 0.0; 
        double totalPullY = 0.0; 

        for (size_t j = 0; j < bodies.size(); ++j) {
            if (i == j) continue;

            double diffX = bodies[j]->getX() - bodies[i]->getX();
            double diffY = bodies[j]->getY() - bodies[i]->getY();
            double distanceSquared = (diffX * diffX) + (diffY * diffY);

            if (distanceSquared < 1.0) distanceSquared = 1.0;

            double distance = std::sqrt(distanceSquared);
            double gravityPull = (gravityStrength * bodies[j]->getMass()) / distanceSquared; 
            
            totalPullX += gravityPull * (diffX / distance);
            totalPullY += gravityPull * (diffY / distance);
        }

        bodies[i]->setPhysicsState(
            bodies[i]->getX(), 
            bodies[i]->getY(), 
            bodies[i]->getSpeedX() + totalPullX, 
            bodies[i]->getSpeedY() + totalPullY
        );
    }

    for (auto& body : bodies) {
        body->setPhysicsState(
            body->getX() + body->getSpeedX(), 
            body->getY() + body->getSpeedY(), 
            body->getSpeedX(), 
            body->getSpeedY()
        );
    }
}

std::string GravityPhysics::getEngineName() const { 
    return "Newtonian Gravity"; 
}
