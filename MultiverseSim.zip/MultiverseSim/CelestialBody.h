#ifndef CELESTIALBODY_H
#define CELESTIALBODY_H

#include <string>
#include <iostream>

class CelestialBody {
protected:
    std::string name;
    double x, y;
    double speedX, speedY;
    double mass; 

public:
    CelestialBody(std::string bodyName, double initialX, double initialY, double initialSpeedX, double initialSpeedY, double bodyMass);
    virtual ~CelestialBody() = default;

    double getX() const;
    double getY() const;
    double getSpeedX() const;
    double getSpeedY() const;
    double getMass() const;

    void setPhysicsState(double newX, double newY, double newSpeedX, double newSpeedY);
    virtual std::string getDetails() const;
    virtual void display() const;
};

class Planet : public CelestialBody {
private:
    std::string atmosphere;
public:
    Planet(std::string bodyName, double x, double y, double speedX, double speedY, double mass, std::string a);
    std::string getDetails() const override;
};

class Star : public CelestialBody {
private:
    int brightness;
public:
    Star(std::string bodyName, double x, double y, double speedX, double speedY, double mass, int b);
    std::string getDetails() const override;
};

class BlackHole : public CelestialBody {
private:
    int pullPower;
public:
    BlackHole(std::string bodyName, double x, double y, double speedX, double speedY, double mass, int pull);
    std::string getDetails() const override;
};

#endif
