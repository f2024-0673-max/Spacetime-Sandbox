#include <iostream>
#include <cstdlib> 
#include <ctime>   
#include "Universe.h"
#include "PhysicsEngine.h"
#include "CelestialBody.h"

using namespace std;

// A simple helper function to get a random decimal number between a min and max
double getRandom(double min, double max) {
    double fraction = (double)rand() / RAND_MAX;
    return min + fraction * (max - min);
}

int main() {
    // 1. Initialize the random seed using the current time
    srand(time(0)); 

    // Let's use our new Gravity physics!
    Universe activeUniverse(make_unique<GravityPhysics>());

    // Start with a massive Star in the center, and a Planet orbiting it
    activeUniverse.addBody(make_unique<Star>("Sun", 0.0, 0.0, 0.0, 0.0, 10000.0, 100));
    activeUniverse.addBody(make_unique<Planet>("Earth", 20.0, 0.0, 0.0, 15.0, 100.0, "Oxygen"));

    int choice = -1;

    cout << "Welcome to the N-Body Gravity Simulator!\n";

    while (choice != 0) {
        cout << "\n========== MAIN MENU ==========\n";
        cout << "1. Display the Universe\n";
        cout << "2. Simulate One Step\n";
        cout << "3. Trigger Supernova (Destroy Everything)\n";
        cout << "4. Add a Random Planet\n";
        cout << "0. Exit Simulator\n";
        cout << "Enter choice: ";
        
        cin >> choice;

        switch (choice) {
            case 1:
                activeUniverse.display();
                break;
            case 2:
                activeUniverse.simulate();
                activeUniverse.display(); // Automatically show result after moving
                break;
            case 3:
                activeUniverse.triggerSupernova();
                break;
            case 4: {
                // Use our simple helper function to generate random numbers!
                double newX = getRandom(-50.0, 50.0);
                double newY = getRandom(-50.0, 50.0);
                double newSpeedX = getRandom(-2.0, 2.0);
                double newSpeedY = getRandom(-2.0, 2.0);
                double newMass = getRandom(10.0, 500.0);
                
                activeUniverse.addBody(make_unique<Planet>("Rogue Planet", newX, newY, newSpeedX, newSpeedY, newMass, "Toxic"));
                cout << "A rogue planet weighing " << newMass << " mass appeared at (" << newX << ", " << newY << ")!\n";
                break;
            }
            case 0:
                cout << "Shutting down the simulation...\n";
                break;
            default:
                cout << "Invalid choice! Please select an option from the menu.\n";
                break;
        }
    }

    return 0;
}