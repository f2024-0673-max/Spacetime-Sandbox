#include "FileHandler.h"
#include <fstream>
#include <iostream>

void FileHandler::saveUniverseToFile(const std::string& filename, const std::string& engineName, const std::vector<std::unique_ptr<CelestialBody>>& bodies) {
    std::ofstream outFile(filename);
    
    if (outFile.is_open()) {
        outFile << "Universe Mode: " << engineName << "\n";
        outFile << "Total Bodies: " << bodies.size() << "\n\n";
        
        for (const auto& body : bodies) {
            outFile << body->getDetails() << "\n";
        }
        
        outFile.close();
        std::cout << "Universe successfully saved to " << filename << "!\n";
    } else {
        std::cout << "Error: Could not open file for writing.\n";
    }
}
