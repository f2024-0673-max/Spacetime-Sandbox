#include "Universe.h"
#include <iostream>

Universe::Universe(std::unique_ptr<IPhysicsEngine> engine)
    : physicsEngine(std::move(engine)) {}

void Universe::addBody(std::unique_ptr<CelestialBody> body) {
    bodies.push_back(std::move(body));
}

void Universe::simulate() {
    if (bodies.empty()) {
        std::cout << "The universe is empty. Nothing happens.\n";
        return;
    }
    physicsEngine->applyPhysics(bodies);
    std::cout << "Simulation advanced 1 step using " << physicsEngine->getEngineName() << " physics.\n";
}

void Universe::display() const {
    std::cout << "\n========== " << physicsEngine->getEngineName() << " Universe ==========\n";
    if (bodies.empty()) {
        std::cout << "This universe is a dark, empty void.\n";
    }
    for (const auto& body : bodies) {
        body->display();
    }
    std::cout << "======================================\n";
}

void Universe::triggerSupernova() {
    std::cout << "\n*** SUPERNOVA OCCURRED! ***\n";
    std::cout << "*** All celestial bodies were incinerated! ***\n";
    bodies.clear(); 
}