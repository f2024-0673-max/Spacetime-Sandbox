#ifndef FILEHANDLER_H
#define FILEHANDLER_H

#include <string>
#include <vector>
#include <memory>
#include "CelestialBody.h"

class FileHandler {
public:
    static void saveUniverseToFile(const std::string& filename, const std::string& engineName, const std::vector<std::unique_ptr<CelestialBody>>& bodies);
};

#endif
